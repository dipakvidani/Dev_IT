ame","Diapak"],["age",23],[{1:1},{2:2}])

// console.log(studentmap);