// Task 3:
// Build a mini calculator that uses callbacks.



function Calculator(expression, callbackMap) {
  const numbers = expression.match(/[0-9.]+/g).map(Number);

  const operator = expression.match(/[\+\-\*\/\%\^]/)[0];

  if (callbackMap[operator]) {
    const result = callbackMap[operator](numbers[0], numbers[1]);
    console.log(`${numbers[0]} ${operator} ${numbers[1]} = ${result}`);
  } else {
    console.log("Invalid operator");
  }
}

const operations = {
  '+': (a, b) => a + b,
  '-': (a, b) => a - b,
  '*': (a, b) => a * b,
  '/': (a, b) => b !== 0 ? a / b : "Error: Divide by zero",
  '%': (a, b) => a % b,
  '^': (a, b) => Math.pow(a, b),
};

Calculator("2.3*3", operations);